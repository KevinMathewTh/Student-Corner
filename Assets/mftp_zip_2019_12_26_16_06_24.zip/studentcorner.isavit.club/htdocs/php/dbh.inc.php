<?php 

$dbServername="sql305.epizy.com";
$dbUsername="epiz_22672583";
$dbPassword="S377jATXPrUfSsG6";
$dbName="epiz_22672583_isa";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);



 ?>